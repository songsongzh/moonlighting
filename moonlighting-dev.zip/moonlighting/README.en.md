# moonlighting

#### Description
该项目是一个大学生校园兼职平台。该平台使用Java语言开发后台业务逻辑，运用了SpringMVC+Spring+MyBatis框架进行搭建,数据库服务器采用MySQL5.6对数据进行持久化。其主要功能有：兼职招聘、论坛交流、在线聊天、个人中心、信箱留言、登录注册等功能。兼职招聘模块用于发布、浏览兼职信息，论坛交流模块用于发布、浏览帖子，在线聊天功能给用户之间进行聊天，在线聊天使得用户之间的沟通更有效率，个人中心用于管理个人数据，信箱留言用于用户对平台提意见，登录注册用于用户进行注册和登录。

#### Software Architecture
Software architecture description

#### Installation

1. xxxx
2. xxxx
3. xxxx

#### Instructions

1. xxxx
2. xxxx
3. xxxx

#### Contribution

1. Fork the repository
2. Create Feat_xxx branch
3. Commit your code
4. Create Pull Request


#### Gitee Feature

1. You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2. Gitee blog [blog.gitee.com](https://blog.gitee.com)
3. Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4. The most valuable open source project [GVP](https://gitee.com/gvp)
5. The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6. The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)